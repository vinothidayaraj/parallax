var section_array = "";
var lastScrollTop = 0;
var scrollFlag = 0;
var snapScroll = $(".parallax").SnapScroll({
	hashes:false,
	animateDuration:500,
});
var previousId = "block-1";

$(".parallax").on(snapScroll.eventChangeActive, function(evt, newActive){
	var elemId = $(".snap-scroll-active").attr("parallax-id");
	$(".section-header").removeClass("selected-header");
	$("#"+elemId+"-menu .header-option .section-header").addClass("selected-header");

	if(previousId != undefined && elemId != undefined && previousId!=elemId){
		setTimeout(function(){
			animateArrow(previousId, elemId);}
		,50);
	}
});

function scrollToDiv(elm){
	$varElem = ($(elm).attr('data-src'));
	$('html, body').animate({
        scrollTop: $("."+$varElem).offset().top
    }, 500);

	$(".section-header").removeClass("selected-header");
	$(elm).addClass("selected-header");
	if(previousId != $varElem){
		animateArrow(previousId, $varElem);
	}
}

function animateArrow(prevDiv, currDiv){
	/*var divDistance = $("#"+prevDiv+"-menu").offset().top - $("#"+currDiv+"-menu").offset().top;
	if(divDistance != 0){
		var traverseDist = divDistance;
		if(divDistance > 0) traverseDist = traverseDist + 10;
		else traverseDist = traverseDist - 50;
		$(".arrowHighlighter").animate({
            marginLeft: (traverseDist+10) + "px"
        }, function () {
            $(this).detach().appendTo("#"+currDiv+"-menu .highlighter-section").css("marginLeft","");
        });
        $('.dotted-scrollbar').animate( { scrollLeft: '-='+divDistance }, 500);
	}
	previousId = currDiv;*/

	if(prevDiv != currDiv){
		console.log(previousId +"---**---"+ currDiv);
		var divDistance = $("#"+prevDiv+"-menu").offset().top - $("#"+currDiv+"-menu").offset().top;
		var traverseDist = ($("#"+prevDiv+"-menu").outerWidth() + $("#"+currDiv+"-menu").outerWidth()) / 2;
		console.log(divDistance +"---"+ traverseDist);
		if(divDistance != 0){
			if(divDistance > 0){
				$('.section-header-container').animate( { scrollLeft: '+='+traverseDist }, 500);
				$('.dotted-scrollbar').animate( { scrollLeft: '+='+traverseDist }, 500);
				/*$('.section-header-container').animate( { right: divDistance + "px" }, 500);
				$('.dotted-scrollbar').animate( { right: divDistance + "px" }, 500);*/
			}else{
				$('.section-header-container').animate( { scrollLeft: '-='+traverseDist }, 500);
				$('.dotted-scrollbar').animate( { scrollLeft: '-='+traverseDist }, 500);
				/*$('.section-header-container').animate( { right: divDistance + "px" }, 500);
				$('.dotted-scrollbar').animate( { right: divDistance + "px" }, 500);*/
			}
			/*if(divDistance > 0) traverseDist = traverseDist + 10;
			else traverseDist = traverseDist - 50;*/
			/*$(".section-header-container").animate({
	            right: traverseDist + "px"
	        }, function () {
	           /* $(this).detach().appendTo("#"+currDiv+"-menu .highlighter-section").css("marginLeft","");
	        });*/
		}
		
		previousId = currDiv;
	}
}

$(document).ready(function(){
    setTimeout(function(){
    	$(this).scrollTop(0);
    },200);
});

var scrollPosition = 0;